def add(x, y):
  """This function adds two numbers."""
  return x + y

def subtract(x, y):
  """This function subtracts two numbers."""
  return x - y

def multiply(x, y):
  """This function multiplies two numbers."""
  return x * y

def divide(x, y):
  """This function divides two numbers, handling division by zero."""
  if y == 0:
      return "Error! Division by zero."
  return x / y

def calculator():
  """Main function to run the calculator program."""
  print("Welcome to the Calculator Program")

  while True:
      print("\nSelect operation:")
      print("1. Addition")
      print("2. Subtraction")
      print("3. Multiplication")
      print("4. Division")
      print("5. Exit")

      # Take input from the user
      choice = input("Enter choice (1/2/3/4/5): ")

      # If the user chooses to exit, break out of the loop
      if choice == '5':
          print("Thank you for using the Calculator Program. Goodbye!")
          break

      # Check if choice is one of the four arithmetic options
      if choice in ['1', '2', '3', '4']:
          try:
              num1 = float(input("Enter first number: "))
              num2 = float(input("Enter second number: "))
          except ValueError:
              print("Invalid input! Please enter numeric values.")
              continue

          if choice == '1':
              print(f"The result of {num1} + {num2} is: {add(num1, num2)}")
          elif choice == '2':
              print(f"The result of {num1} - {num2} is: {subtract(num1, num2)}")
          elif choice == '3':
              print(f"The result of {num1} * {num2} is: {multiply(num1, num2)}")
          elif choice == '4':
              result = divide(num1, num2)
              print(f"The result of {num1} / {num2} is: {result}")
      else:
          print("Invalid Input. Please select a valid operation.")

if __name__ == "__main__":
  calculator()